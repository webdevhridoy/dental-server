# Here i'm going to add Assignment-10 - backend api related some points that I have followed and made it:

1.  I have installed:

- express js
- nodemon js
- mongoDB

2.  For CORS error I have installed

- CORS from express

3.  Let's talk about the functionality that you will in my website.

- I saved my data using mongoDB
- Here I have run CRUD operation
- I have also created dynamic API
